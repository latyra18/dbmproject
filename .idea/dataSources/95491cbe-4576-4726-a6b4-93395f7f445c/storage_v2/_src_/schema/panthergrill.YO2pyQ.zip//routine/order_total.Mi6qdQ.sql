create
    definer = root@localhost procedure order_total()
BEGIN
select sum(price) as total from (select orders.idOrder, fooditems.idItem as fooditem, menu.idItem, menu.price from orders join fooditems ON orders.idOrder = fooditems.idOrder
join menu on fooditems.idItem = menu.idItem group by idOrder) as price;
END;

