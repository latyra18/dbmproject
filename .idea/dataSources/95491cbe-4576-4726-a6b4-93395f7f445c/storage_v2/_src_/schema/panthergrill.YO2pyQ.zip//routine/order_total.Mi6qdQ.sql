create
    definer = root@localhost procedure order_total()
BEGIN
select sum(price) as price from (SELECT fooditems.idItem, menu.price FROM panthergrill.fooditems 
join menu on fooditems.idItem = menu.idItem where fooditems.idOrder = 1) as price;
END;

