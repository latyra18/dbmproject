create definer = root@localhost view twoweek_schedule as
select `panthergrill`.`employee`.`idemployee` AS `idemployee`,
       `panthergrill`.`schedule`.`date`       AS `date`,
       `panthergrill`.`location`.`address`    AS `address`,
       `panthergrill`.`shifts`.`shiftType`    AS `shiftType`
from (((`panthergrill`.`schedule` join `panthergrill`.`shifts` on ((`panthergrill`.`shifts`.`idShift` =
                                                                    `panthergrill`.`schedule`.`idShift`))) join `panthergrill`.`location` on ((
        `panthergrill`.`location`.`idlocation` = `panthergrill`.`schedule`.`idLocation`)))
         join `panthergrill`.`employee`
              on ((`panthergrill`.`employee`.`idemployee` = `panthergrill`.`schedule`.`idEmployee`)))
where ((`panthergrill`.`schedule`.`date` >= curdate()) and (`panthergrill`.`schedule`.`date` < (curdate() + 14)))
order by `panthergrill`.`schedule`.`date`;

